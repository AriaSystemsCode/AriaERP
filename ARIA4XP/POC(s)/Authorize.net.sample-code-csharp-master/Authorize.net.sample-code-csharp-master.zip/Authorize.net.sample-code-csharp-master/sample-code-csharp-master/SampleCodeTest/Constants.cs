﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SampleCodeTest
{
    class Constants
    {


        public static string API_LOGIN_ID = "6c8D8UtL";
        public static string TRANSACTION_KEY = "27gJ32cZ2cFMx3xD";
        public static string TRANSACTION_ID = "123456";
        public static string PAYER_ID = "6ZSCSYG33VP8Q";
        public static string CONFIG_FILE = "../../SampleCodeList.txt";
    }
}
